# Mini serveur MCP en PHP — guide pratique

## Objectif

Ce document résume, de manière complète mais digeste, la mise en place d’un **mini serveur MCP en PHP**, son test avec **MCP Inspector**, les erreurs rencontrées, les commandes utilisées, et l’explication de ce que fait chaque élément.

---

## 1. Qu’est-ce qu’un serveur MCP ?

Un **serveur MCP** n’est pas une IA en lui-même.

C’est un **programme qui expose des capacités** de manière standardisée, par exemple :
- des outils (*tools*),
- des ressources (*resources*),
- des prompts.

L’IA, elle, se trouve généralement **dans le client qui se connecte au serveur MCP**.

### Dans notre exemple

- **Serveur MCP PHP** : expose une tool `bonjour`
- **MCP Inspector** : client de test
- **IA** : absente de notre test

Donc ici, nous avons construit **la boîte à outils**, pas l’intelligence qui décide quoi appeler.

---

## 2. Architecture très simple

```text
Utilisateur → Client MCP / IA → Serveur MCP PHP
```

Dans notre cas de test :

```text
Utilisateur → MCP Inspector → Serveur MCP PHP
```

L’Inspector remplace simplement le client final et permet de tester manuellement les tools.

---

## 3. Pré-requis

### PHP

Nous avons utilisé PHP en ligne de commande.

Commande de vérification :

```powershell
php -v
```

### Composer

Commande de vérification :

```powershell
composer -V
```

### Node.js / npm / npx

Nécessaire pour lancer **MCP Inspector**.

Commandes utiles :

```powershell
npm -v
npx -v
```

---

## 4. Installation du SDK MCP pour PHP

Commande :

```powershell
composer require mcp/sdk
```

### Problème rencontré

L’installation a d’abord échoué avec une erreur d’extraction d’archive :

```text
Failed to extract php-http/discovery
```

### Cause probable

- extension PHP `zip` non activée
- Composer utilisait un `7z.exe` bizarre trouvé dans un dossier Lua
- environnement Windows + proxy + extraction ZIP fragile

---

## 5. Diagnostic Composer et PHP

### Commandes utiles

```powershell
where.exe php
where.exe 7z
php -m | Select-String zip
composer diagnose
```

### Ce que nous avons constaté

- PHP était bien trouvé :
  - `C:\Php847\php.exe`
- `7z.exe` pointait vers :
  - `C:\Program Files (x86)\Lua\5.1\7z.exe`
- l’extension `zip` n’était pas chargée

### Conséquence

Composer devait s’appuyer sur un extracteur externe au lieu de `ZipArchive`.

---

## 6. Problème npm / proxy

Lors du lancement de l’Inspector, nous avons eu une erreur réseau :

```text
npm error code ETIMEDOUT
npm error network request to https://registry.npmjs.org/... failed
```

### Cause

Le réseau passait par un proxy d’entreprise non configuré dans npm.

### Solution

```powershell
npm config set proxy http://10.235.1.14:8080
npm config set https-proxy http://10.235.1.14:8080
npm ping
```

### Résultat

`npm ping` a répondu :

```text
npm notice PONG
```

Ce qui a confirmé que npm pouvait enfin joindre le registre.

---

## 7. Structure du projet

```text
mcp/
├─ composer.json
├─ server.php
├─ src/
│  └─ HelloMcp.php
└─ vendor/
```

---

## 8. Fichier `composer.json`

Version finale correcte :

```json
{
    "require": {
        "mcp/sdk": "^0.4.0"
    },
    "autoload": {
        "psr-4": {
            "App\\": "src/"
        }
    },
    "config": {
        "allow-plugins": {
            "php-http/discovery": true
        }
    }
}
```

### Pourquoi `autoload` était important

Sans cette partie :

```json
"autoload": {
    "psr-4": {
        "App\\": "src/"
    }
}
```

Composer ne savait pas charger automatiquement la classe `App\HelloMcp`.

### Après modification

Nous avons régénéré l’autoload avec :

```powershell
composer dump-autoload
```

---

## 9. Fichier `src/HelloMcp.php`

Code final :

```php
<?php

declare(strict_types=1);

namespace App;

use Mcp\Capability\Attribute\McpTool;

final class HelloMcp
{
    #[McpTool(name: 'bonjour')]
    public function bonjour(string $nom = 'Alain'): string
    {
        return "Bonjour {$nom} ! Bienvenue sur mon mini serveur MCP PHP.";
    }
}
```

### Explication

- `namespace App;` : namespace de la classe
- `#[McpTool(name: 'bonjour')]` : déclare une tool MCP
- `bonjour(...)` : fonction PHP exposée à travers MCP

Cette méthode peut ensuite être appelée par un client MCP.

---

## 10. Fichier `server.php`

Version finale correcte :

```php
<?php

declare(strict_types=1);

require_once __DIR__ . '/vendor/autoload.php';

use Mcp\Server;
use Mcp\Server\Transport\StdioTransport;

$server = Server::builder()
    ->setServerInfo('Mini PHP MCP Server', '1.0.0')
    ->setDiscovery(__DIR__)
    ->build();

$transport = new StdioTransport();

$server->run($transport);
```

### Explication

- `require_once __DIR__ . '/vendor/autoload.php';` : charge l’autoload Composer
- `Server::builder()` : crée le serveur MCP
- `setServerInfo(...)` : nom et version du serveur
- `setDiscovery(__DIR__)` : demande au SDK de scanner le projet pour découvrir les capacités MCP
- `StdioTransport` : transport via l’entrée/sortie standard
- `run(...)` : lance le serveur

---

## 11. Erreur importante sur la découverte

Nous avions d’abord ceci :

```php
->setDiscovery(__DIR__ . '/src', ['App'])
```

### Pourquoi c’était mauvais

Le second argument n’est pas une liste de namespaces à scanner.
C’est une liste de **répertoires**.

Le SDK essayait donc de scanner un dossier `App` à l’intérieur de `src`, ce qui ne correspondait pas à notre structure.

### Résultat

Le serveur se connectait, mais l’Inspector affichait :

```text
The connected server does not support any MCP capabilities
```

### Correction

```php
->setDiscovery(__DIR__)
```

Cette correction a permis à la tool `bonjour` d’être découverte.

---

## 12. Tests utiles en ligne de commande

### Vérifier que Composer voit bien la classe

```powershell
php -r "require 'vendor/autoload.php'; var_dump(class_exists('App\\HelloMcp'));"
```

### Résultat attendu

```text
bool(true)
```

### Tester la classe directement

```powershell
php -r "require 'vendor/autoload.php'; $x = new App\HelloMcp(); echo $x->bonjour('Alain');"
```

### Résultat attendu

```text
Bonjour Alain ! Bienvenue sur mon mini serveur MCP PHP.
```

---

## 13. Lancer le serveur MCP

Commande :

```powershell
php server.php
```

### Comportement normal

La console semble “tourner dans le vide”.

En réalité, le serveur :
- n’est pas planté,
- attend un client MCP,
- reste en écoute sur l’entrée/sortie standard.

Il ne faut rien taper dans cette fenêtre.

---

## 14. Lancer MCP Inspector

Commande :

```powershell
npx @modelcontextprotocol/inspector php D:\www\htdocs\prj\mcp\server.php
```

### Que fait cette commande ?

Elle signifie en pratique :

- lance **MCP Inspector** via `npx`
- demande à l’Inspector d’exécuter :

```powershell
php D:\www\htdocs\prj\mcp\server.php
```

- connecte l’Inspector au serveur MCP via **STDIO**
- ouvre une interface locale dans le navigateur
- permet de tester les tools exposées

### Décomposition

- `npx` : exécute un package Node temporairement
- `@modelcontextprotocol/inspector` : client de test MCP
- `php` : commande utilisée pour lancer le serveur
- `D:\www\htdocs\prj\mcp\server.php` : fichier serveur à exécuter

---

## 15. Problème de chemin Windows dans l’Inspector

Nous avons eu ce message :

```json
{
  "method": "notifications/message",
  "params": {
    "level": "info",
    "logger": "stdio",
    "data": {
      "message": "Could not open input file: D:wwwhtdocsprjmcpserver.php"
    }
  }
}
```

### Cause

Les antislashs `\` du chemin Windows étaient mal interprétés.

### Solution

Utiliser des **slashes normaux** :

```text
D:/www/htdocs/prj/mcp/server.php
```

Cela fonctionne très bien avec PHP sous Windows.

---

## 16. Erreur JSON-RPC `Syntax error`

Nous avons aussi vu :

```json
{"jsonrpc":"2.0","id":"","error":{"code":-32700,"message":"Syntax error"}}
```

### Cause

Cette erreur est apparue parce qu’une commande du type :

```powershell
npx @modelcontextprotocol/inspector php /path/to/server.php
```

avait été tapée **dans la console du serveur déjà lancé**.

Or un serveur MCP en STDIO attend du **JSON-RPC**, pas une commande texte.

### Conclusion

- ne pas utiliser la fenêtre où `php server.php` tourne pour taper d’autres commandes
- ouvrir un autre terminal pour lancer l’Inspector

---

## 17. Ce que nous avons obtenu au final

Dans l’Inspector :
- la tool `bonjour` apparaît
- on peut saisir `nom = Alain`
- l’exécution renvoie :

```text
Bonjour Alain ! Bienvenue sur mon mini serveur MCP PHP.
```

Cela confirme que :
- le serveur MCP fonctionne,
- la tool est bien découverte,
- le transport STDIO fonctionne,
- l’Inspector peut appeler la capacité.

---

## 18. Où est l’IA dans tout cela ?

C’est l’une des questions les plus importantes du sujet.

### Réponse courte

L’IA **n’est pas dans le serveur MCP**.

Le serveur MCP expose des capacités.
L’IA est généralement dans le **client** qui décide d’utiliser ces capacités.

### Dans notre démonstration

- le serveur MCP expose `bonjour`
- l’Inspector te laisse l’appeler manuellement
- donc ici, **c’est toi** qui fais le travail de décision

### Avec une vraie IA connectée

On aurait quelque chose comme :

1. l’utilisateur dit : « Salue Alain »
2. l’IA comprend qu’elle peut utiliser la tool `bonjour`
3. elle l’appelle avec `nom = Alain`
4. elle récupère le résultat
5. elle répond

Donc le serveur MCP est plutôt :

> une API standardisée orientée outils pour clients MCP / IA

---

## 19. Résumé des commandes utilisées

### Vérifications système

```powershell
where.exe php
where.exe 7z
php -m | Select-String zip
composer diagnose
```

### Installation / Composer

```powershell
composer require mcp/sdk
composer dump-autoload
composer clear-cache
```

### Proxy npm

```powershell
npm config set proxy http://10.235.1.14:8080
npm config set https-proxy http://10.235.1.14:8080
npm ping
```

### Tests PHP

```powershell
php -r "require 'vendor/autoload.php'; var_dump(class_exists('App\\HelloMcp'));"
php -r "require 'vendor/autoload.php'; $x = new App\HelloMcp(); echo $x->bonjour('Alain');"
```

### Lancement du serveur

```powershell
php server.php
```

### Lancement de l’Inspector

```powershell
npx @modelcontextprotocol/inspector php D:\www\htdocs\prj\mcp\server.php
```

ou, dans l’interface, avec le chemin :

```text
D:/www/htdocs/prj/mcp/server.php
```

---

## 20. Conclusion

Nous avons mis en place un **mini serveur MCP en PHP pleinement fonctionnel**.

### Ce qui est validé

- installation du SDK MCP PHP
- configuration Composer correcte
- autoload PSR-4
- création d’une tool avec attribut `McpTool`
- lancement d’un serveur MCP via `StdioTransport`
- test avec MCP Inspector
- exécution réussie de la tool `bonjour`

### Ce que cela t’apporte

Tu disposes maintenant d’un **socle fonctionnel** pour créer des tools plus utiles, par exemple :
- `additionner(a, b)`
- lecture d’un fichier JSON
- accès à une base de données
- appel à un service métier
- intégration future à un assistant IA réel

---

## 21. Idées pour la suite

Exemple d’ajout d’une deuxième tool :

```php
#[McpTool(name: 'additionner')]
public function additionner(int $a, int $b): int
{
    return $a + $b;
}
```

Après redémarrage de l’Inspector, cette tool apparaîtra aussi.

---

## 22. Fichiers finaux récapitulés

### `composer.json`

```json
{
    "require": {
        "mcp/sdk": "^0.4.0"
    },
    "autoload": {
        "psr-4": {
            "App\\": "src/"
        }
    },
    "config": {
        "allow-plugins": {
            "php-http/discovery": true
        }
    }
}
```

### `src/HelloMcp.php`

```php
<?php

declare(strict_types=1);

namespace App;

use Mcp\Capability\Attribute\McpTool;

final class HelloMcp
{
    #[McpTool(name: 'bonjour')]
    public function bonjour(string $nom = 'Alain'): string
    {
        return "Bonjour {$nom} ! Bienvenue sur mon mini serveur MCP PHP.";
    }
}
```

### `server.php`

```php
<?php

declare(strict_types=1);

require_once __DIR__ . '/vendor/autoload.php';

use Mcp\Server;
use Mcp\Server\Transport\StdioTransport;

$server = Server::builder()
    ->setServerInfo('Mini PHP MCP Server', '1.0.0')
    ->setDiscovery(__DIR__)
    ->build();

$transport = new StdioTransport();

$server->run($transport);
```

---

Fin du document.
